﻿using System.Windows;

namespace GenshinImpactProfileQuery.Views
{
    /// <summary>
    ///     LoadingWindow.xaml 的交互逻辑
    /// </summary>
    public partial class LoadingWindow : Window
    {
        public LoadingWindow()
        {
            InitializeComponent();
        }
    }
}
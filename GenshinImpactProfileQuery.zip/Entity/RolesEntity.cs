﻿namespace GenshinImpactProfileQuery.Entity
{
    public class RolesEntity
    {
        public string Avatar { get; set; }

        public string Index { get; set; }

        public string Name { get; set; }

        public string Rarity { get; set; }

        public string Element { get; set; }

        public string Level { get; set; }

        public string Fetter { get; set; }
    }
}